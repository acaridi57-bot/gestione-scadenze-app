import { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Plus, 
  Calendar,
  ArrowUpDown,
  VolumeX,
  Volume2,
  Send,
  Bell,
  BellRing,
  BarChart3,
  Printer,
  Download,
  FileSpreadsheet,
  FileJson,
  Database,
  CalendarIcon,
  X,
  AlertTriangle,
  Loader2,
  Square
} from 'lucide-react';
import { MainLayout } from '@/components/layout/MainLayout';
import { NavigationButtons } from '@/components/layout/NavigationButtons';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { useReminders, Reminder } from '@/hooks/useReminders';
import { useNotifications } from '@/hooks/useNotifications';
import { useTTS } from '@/hooks/useTTS';
import { format, isBefore, isAfter, startOfDay, endOfDay, differenceInDays } from 'date-fns';
import { it } from 'date-fns/locale';
import { AddReminderDialog } from '@/components/reminders/AddReminderDialog';
import { RemindersYearChart } from '@/components/reminders/RemindersYearChart';
import { ReminderActions } from '@/components/reminders/ReminderActions';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import euroCoin from '@/assets/2-euro-coin.png';

type FilterType = 'all' | 'pending' | 'completed';
type SortOrder = 'date-asc' | 'date-desc' | 'amount-desc' | 'amount-asc';

export default function Reminders() {
  const { reminders, isLoading } = useReminders();
  const { 
    notificationsEnabled, 
    permission, 
    checkUpcomingReminders,
    sendNotification 
  } = useNotifications();
  const { speak, stop, isPlaying, isLoading: isTTSLoading } = useTTS();
  const [filter, setFilter] = useState<FilterType>('all');
  const [sortOrder, setSortOrder] = useState<SortOrder>('date-asc');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);

  // Handle voice toggle and read reminders
  const handleVoiceToggle = () => {
    if (isPlaying) {
      stop();
      setVoiceEnabled(false);
      return;
    }

    const pendingReminders = reminders.filter(r => !r.completed);
    if (pendingReminders.length === 0) {
      toast.info('Nessun promemoria da leggere');
      return;
    }

    // Build text to speak
    const today = new Date();
    const textParts = pendingReminders.slice(0, 5).map(r => {
      const dueDate = new Date(r.due_date);
      const daysUntil = differenceInDays(dueDate, today);
      
      let dateText = '';
      if (daysUntil < 0) {
        dateText = 'scaduto';
      } else if (daysUntil === 0) {
        dateText = 'oggi';
      } else if (daysUntil === 1) {
        dateText = 'domani';
      } else {
        dateText = `tra ${daysUntil} giorni`;
      }

      const amountText = r.amount ? `, importo ${Number(r.amount).toFixed(0)} euro` : '';
      return `${r.title}, scade ${dateText}${amountText}`;
    });

    const intro = pendingReminders.length === 1 
      ? 'Hai un promemoria in sospeso.'
      : `Hai ${pendingReminders.length} promemoria in sospeso.`;

    const fullText = `${intro} ${textParts.join('. ')}.`;
    
    setVoiceEnabled(true);
    speak(fullText);
  };

  // Count upcoming reminders (within 3 days)
  const upcomingCount = useMemo(() => {
    const today = new Date();
    return reminders.filter(r => {
      if (r.completed) return false;
      const dueDate = new Date(r.due_date);
      const daysUntil = differenceInDays(dueDate, today);
      return daysUntil >= 0 && daysUntil <= 3;
    }).length;
  }, [reminders]);

  // Check for upcoming reminders on load
  useEffect(() => {
    if (notificationsEnabled && permission === 'granted') {
      checkUpcomingReminders();
    }
  }, [notificationsEnabled, permission, checkUpcomingReminders]);

  // Handle notify button click
  const handleNotifyClick = () => {
    if (permission !== 'granted') {
      toast.warning('Abilita le notifiche nelle impostazioni');
      return;
    }

    const today = new Date();
    const upcomingReminders = reminders.filter(r => {
      if (r.completed) return false;
      const dueDate = new Date(r.due_date);
      const daysUntil = differenceInDays(dueDate, today);
      return daysUntil >= 0 && daysUntil <= 7;
    });

    if (upcomingReminders.length === 0) {
      toast.info('Nessuna scadenza imminente');
      return;
    }

    upcomingReminders.forEach(reminder => {
      const dueDate = new Date(reminder.due_date);
      const daysUntil = differenceInDays(dueDate, today);
      
      let message = '';
      if (daysUntil === 0) {
        message = 'Scade oggi!';
      } else if (daysUntil === 1) {
        message = 'Scade domani!';
      } else {
        message = `Scade tra ${daysUntil} giorni`;
      }

      const amountText = reminder.amount 
        ? ` - ${formatCurrency(Number(reminder.amount))}`
        : '';

      sendNotification(`📅 ${reminder.title}`, {
        body: `${message}${amountText}`,
        tag: `reminder-${reminder.id}`,
      });
    });

    toast.success(`${upcomingReminders.length} notifiche inviate`);
  };

  const filteredReminders = useMemo(() => {
    let result = [...reminders];

    // Filter by status
    if (filter === 'pending') {
      result = result.filter(r => !r.completed);
    } else if (filter === 'completed') {
      result = result.filter(r => r.completed);
    }

    // Filter by date range
    if (startDate) {
      result = result.filter(r => !isBefore(new Date(r.due_date), startOfDay(startDate)));
    }
    if (endDate) {
      result = result.filter(r => !isAfter(new Date(r.due_date), endOfDay(endDate)));
    }

    // Sort
    result.sort((a, b) => {
      switch (sortOrder) {
        case 'date-desc':
          return new Date(b.due_date).getTime() - new Date(a.due_date).getTime();
        case 'date-asc':
          return new Date(a.due_date).getTime() - new Date(b.due_date).getTime();
        case 'amount-desc':
          return (Number(b.amount) || 0) - (Number(a.amount) || 0);
        case 'amount-asc':
          return (Number(a.amount) || 0) - (Number(b.amount) || 0);
        default:
          return 0;
      }
    });

    return result;
  }, [reminders, filter, sortOrder, startDate, endDate]);

  const clearDateFilters = () => {
    setStartDate(undefined);
    setEndDate(undefined);
  };

  const totalYear = useMemo(() => {
    const currentYear = new Date().getFullYear();
    return reminders
      .filter(r => new Date(r.due_date).getFullYear() === currentYear)
      .reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
  }, [reminders]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR'
    }).format(value);
  };

  const getSortLabel = (order: SortOrder) => {
    switch (order) {
      case 'date-asc':
        return 'Data ↑ (crescente)';
      case 'date-desc':
        return 'Data ↓ (decrescente)';
      case 'amount-desc':
        return 'Importo ↓';
      case 'amount-asc':
        return 'Importo ↑';
    }
  };

  const getFilterLabel = (f: FilterType) => {
    switch (f) {
      case 'all':
        return `Tutti (${reminders.length})`;
      case 'pending':
        return 'In sospeso';
      case 'completed':
        return 'Completati';
    }
  };

  const prepareExportData = () => {
    return filteredReminders.map(r => ({
      titolo: r.title,
      descrizione: r.description || '',
      scadenza: format(new Date(r.due_date), 'dd/MM/yyyy'),
      importo: Number(r.amount) || 0,
      categoria: r.categories?.name || 'Altro',
      completato: r.completed ? 'Sì' : 'No',
      giorni_preavviso: r.notify_days_before || 3,
    }));
  };

  const downloadFile = (content: string, filename: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    const printContent = `
      <html>
        <head>
          <title>Promemoria</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            h1 { color: #333; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
            th { background-color: #f5f5f5; }
            .completed { text-decoration: line-through; color: #999; }
            .overdue { color: #ef4444; }
          </style>
        </head>
        <body>
          <h1>Promemoria</h1>
          <p>Esportato il: ${format(new Date(), 'dd/MM/yyyy HH:mm')}</p>
          <table>
            <thead>
              <tr>
                <th>Titolo</th>
                <th>Scadenza</th>
                <th>Importo</th>
                <th>Categoria</th>
                <th>Stato</th>
              </tr>
            </thead>
            <tbody>
              ${filteredReminders.map(r => `
                <tr class="${r.completed ? 'completed' : isBefore(new Date(r.due_date), new Date()) ? 'overdue' : ''}">
                  <td>${r.title}</td>
                  <td>${format(new Date(r.due_date), 'dd/MM/yyyy')}</td>
                  <td>${r.amount ? formatCurrency(Number(r.amount)) : '-'}</td>
                  <td>${r.categories?.name || 'Altro'}</td>
                  <td>${r.completed ? '✓ Completato' : 'In sospeso'}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <div style="margin-top: 20px; font-weight: bold;">
            <p>Totale: ${formatCurrency(filteredReminders.reduce((sum, r) => sum + (Number(r.amount) || 0), 0))}</p>
          </div>
        </body>
      </html>
    `;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
    toast.success('Stampa avviata');
  };

  const handleExportCSV = () => {
    const data = prepareExportData();
    const headers = ['Titolo', 'Descrizione', 'Scadenza', 'Importo', 'Categoria', 'Completato', 'Giorni Preavviso'];
    const csvContent = [
      headers.join(';'),
      ...data.map(row => [
        `"${row.titolo}"`,
        `"${row.descrizione}"`,
        row.scadenza,
        row.importo.toFixed(2).replace('.', ','),
        row.categoria,
        row.completato,
        row.giorni_preavviso
      ].join(';'))
    ].join('\n');
    
    downloadFile(csvContent, 'promemoria.csv', 'text/csv;charset=utf-8');
    toast.success('CSV esportato');
  };

  const handleExportJSON = () => {
    const data = prepareExportData();
    const jsonContent = JSON.stringify(data, null, 2);
    downloadFile(jsonContent, 'promemoria.json', 'application/json');
    toast.success('JSON esportato');
  };

  const handleExportSQL = () => {
    const data = prepareExportData();
    const sqlStatements = data.map(row => 
      `INSERT INTO promemoria (titolo, descrizione, scadenza, importo, categoria, completato, giorni_preavviso) VALUES ('${row.titolo.replace(/'/g, "''")}', '${row.descrizione.replace(/'/g, "''")}', '${row.scadenza}', ${row.importo}, '${row.categoria}', '${row.completato}', ${row.giorni_preavviso});`
    ).join('\n');
    
    const sqlContent = `-- Promemoria esportati il ${format(new Date(), 'dd/MM/yyyy HH:mm')}\n-- Totale: ${data.length} record\n\n${sqlStatements}`;
    downloadFile(sqlContent, 'promemoria.sql', 'text/plain');
    toast.success('SQL esportato');
  };

  const handleExportExcel = () => {
    const data = prepareExportData();
    const headers = ['Titolo', 'Descrizione', 'Scadenza', 'Importo', 'Categoria', 'Completato', 'Giorni Preavviso'];
    
    const BOM = '\uFEFF';
    const csvContent = BOM + [
      headers.join('\t'),
      ...data.map(row => [
        row.titolo,
        row.descrizione,
        row.scadenza,
        row.importo.toFixed(2),
        row.categoria,
        row.completato,
        row.giorni_preavviso
      ].join('\t'))
    ].join('\n');
    
    downloadFile(csvContent, 'promemoria.xls', 'application/vnd.ms-excel;charset=utf-8');
    toast.success('Excel esportato');
  };

  const handleExportPDF = () => {
    const printContent = `
      <html>
        <head>
          <title>Promemoria - PDF</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            h1 { color: #333; margin-bottom: 5px; }
            .subtitle { color: #666; margin-bottom: 20px; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 12px; }
            th { background-color: #f5f5f5; font-weight: bold; }
            .completed { text-decoration: line-through; color: #999; }
            .overdue { color: #ef4444; }
            .totals { margin-top: 20px; font-weight: bold; }
          </style>
        </head>
        <body>
          <h1>Promemoria</h1>
          <p class="subtitle">Esportato il: ${format(new Date(), 'dd/MM/yyyy HH:mm')}</p>
          <table>
            <thead>
              <tr>
                <th>Titolo</th>
                <th>Scadenza</th>
                <th>Importo</th>
                <th>Categoria</th>
                <th>Stato</th>
              </tr>
            </thead>
            <tbody>
              ${filteredReminders.map(r => `
                <tr class="${r.completed ? 'completed' : isBefore(new Date(r.due_date), new Date()) ? 'overdue' : ''}">
                  <td>${r.title}</td>
                  <td>${format(new Date(r.due_date), 'dd/MM/yyyy')}</td>
                  <td>${r.amount ? formatCurrency(Number(r.amount)) : '-'}</td>
                  <td>${r.categories?.name || 'Altro'}</td>
                  <td>${r.completed ? '✓ Completato' : 'In sospeso'}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <div class="totals">
            <p>Totale Promemoria: ${formatCurrency(filteredReminders.reduce((sum, r) => sum + (Number(r.amount) || 0), 0))}</p>
            <p>In sospeso: ${filteredReminders.filter(r => !r.completed).length} | Completati: ${filteredReminders.filter(r => r.completed).length}</p>
          </div>
        </body>
      </html>
    `;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      toast.info('Usa "Salva come PDF" nel dialogo di stampa');
      setTimeout(() => printWindow.print(), 500);
    }
  };

  return (
    <MainLayout>
      <div className="p-4 md:p-6 max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="coin-container">
              <div className="banknote-shine coin-rotate w-10 h-10 rounded-full">
                <img src={euroCoin} alt="Euro" className="w-10 h-10 object-contain" />
              </div>
            </div>
            <motion.h1
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-2xl md:text-3xl font-bold text-[#067d1c]"
            >
              Promemoria
            </motion.h1>
          </div>
          
          <div className="flex items-center gap-2 flex-wrap">
            <NavigationButtons />
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleVoiceToggle}
              disabled={isTTSLoading}
              className="gap-2 text-primary border-primary/30 hover:bg-primary/10"
            >
              {isTTSLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : isPlaying ? (
                <Square className="w-4 h-4" />
              ) : voiceEnabled ? (
                <Volume2 className="w-4 h-4" />
              ) : (
                <VolumeX className="w-4 h-4" />
              )}
              {isTTSLoading ? 'Carico...' : isPlaying ? 'Stop' : 'Leggi'}
            </Button>
            <Button variant="outline" size="sm" className="gap-2 text-primary border-primary/30 hover:bg-primary/10">
              <Send className="w-4 h-4" />
              Riepilogo
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="gap-2 text-primary border-primary/30 hover:bg-primary/10 relative"
              onClick={handleNotifyClick}
            >
              {upcomingCount > 0 ? (
                <BellRing className="w-4 h-4" />
              ) : (
                <Bell className="w-4 h-4" />
              )}
              Notifica Scadenze
              {upcomingCount > 0 && (
                <Badge 
                  variant="destructive" 
                  className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs"
                >
                  {upcomingCount}
                </Badge>
              )}
            </Button>
            <Button 
              onClick={() => setDialogOpen(true)}
              className="gradient-primary text-primary-foreground shadow-glow"
            >
              <Plus className="w-4 h-4 mr-2" />
              Aggiungi
            </Button>
          </div>
        </div>

        {/* Filters and Export */}
        <div className="flex flex-col gap-4 mb-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-2 flex-wrap">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-2 text-primary border-primary/30 hover:bg-primary/10">
                    <Calendar className="w-4 h-4" />
                    {getFilterLabel(filter)}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setFilter('all')}>
                    Tutti ({reminders.length})
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setFilter('pending')}>
                    In sospeso
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setFilter('completed')}>
                    Completati
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-2 text-primary border-primary/30 hover:bg-primary/10">
                    <ArrowUpDown className="w-4 h-4" />
                    {getSortLabel(sortOrder)}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setSortOrder('date-asc')}>
                    Data ↑ (crescente)
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSortOrder('date-desc')}>
                    Data ↓ (decrescente)
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSortOrder('amount-desc')}>
                    Importo ↓
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSortOrder('amount-asc')}>
                    Importo ↑
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* Date Range Filters */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm text-muted-foreground">Dal:</span>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className={cn(
                      "w-[130px] justify-start text-left font-normal text-primary border-primary/30 hover:bg-primary/10",
                      !startDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4 text-[#067d1c]" />
                    {startDate ? format(startDate, "dd/MM/yyyy") : "Seleziona"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={startDate}
                    onSelect={setStartDate}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>

              <span className="text-sm text-muted-foreground">Al:</span>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className={cn(
                      "w-[130px] justify-start text-left font-normal text-primary border-primary/30 hover:bg-primary/10",
                      !endDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4 text-[#067d1c]" />
                    {endDate ? format(endDate, "dd/MM/yyyy") : "Seleziona"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={endDate}
                    onSelect={setEndDate}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>

              {(startDate || endDate) && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearDateFilters}
                  className="h-8 px-2"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>

          {/* Export Buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <Button variant="outline" size="sm" className="text-primary border-primary/30 hover:bg-primary/10" onClick={handlePrint}>
              <Printer className="w-4 h-4 mr-2" />
              Stampa
            </Button>
            <Button variant="outline" size="sm" className="text-primary border-primary/30 hover:bg-primary/10" onClick={handleExportCSV}>
              <Download className="w-4 h-4 mr-2" />
              CSV
            </Button>
            <Button variant="outline" size="sm" className="text-primary border-primary/30 hover:bg-primary/10" onClick={handleExportPDF}>
              <Download className="w-4 h-4 mr-2" />
              PDF
            </Button>
            <Button variant="outline" size="sm" className="text-primary border-primary/30 hover:bg-primary/10" onClick={handleExportExcel}>
              <FileSpreadsheet className="w-4 h-4 mr-2" />
              Excel
            </Button>
            <Button variant="outline" size="sm" className="text-primary border-primary/30 hover:bg-primary/10" onClick={handleExportJSON}>
              <FileJson className="w-4 h-4 mr-2" />
              JSON
            </Button>
            <Button variant="outline" size="sm" className="text-primary border-primary/30 hover:bg-primary/10" onClick={handleExportSQL}>
              <Database className="w-4 h-4 mr-2" />
              SQL
            </Button>
          </div>
        </div>

        {/* Year Chart */}
        <Card className="shadow-card mb-6">
          <CardHeader className="flex flex-row items-center gap-2 pb-2">
            <BarChart3 className="w-5 h-5 text-[#067d1c]" />
            <CardTitle className="text-lg text-[#067d1c]">Scadenze</CardTitle>
          </CardHeader>
          <CardContent>
            <RemindersYearChart reminders={reminders} />
          </CardContent>
        </Card>

        {/* Reminders List */}
        <Card className="shadow-card">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center gap-2 mb-4">
              <Calendar className="w-5 h-5 text-[#067d1c]" />
              <span className="font-semibold text-[#067d1c]">
                Promemoria ({filteredReminders.length})
              </span>
            </div>

            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : filteredReminders.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                Nessun promemoria trovato
              </div>
            ) : (
              <div className="space-y-3">
                {filteredReminders.map((reminder, index) => (
                  <ReminderItem 
                    key={reminder.id} 
                    reminder={reminder}
                    formatCurrency={formatCurrency}
                    delay={index * 0.05}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <AddReminderDialog open={dialogOpen} onOpenChange={setDialogOpen} />
      </div>
    </MainLayout>
  );
}

interface ReminderItemProps {
  reminder: Reminder;
  formatCurrency: (value: number) => string;
  delay: number;
}

function ReminderItem({ reminder, formatCurrency, delay }: ReminderItemProps) {
  const dueDate = new Date(reminder.due_date);
  const isOverdue = isBefore(dueDate, new Date()) && !reminder.completed;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className={`p-4 rounded-xl border transition-colors ${
        reminder.completed 
          ? 'bg-muted/30 border-border' 
          : isOverdue 
            ? 'bg-expense/5 border-expense/20' 
            : 'bg-secondary/30 border-transparent'
      }`}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <h3 className={`font-semibold ${reminder.completed ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
            {reminder.categories?.name || 'Altro'} - {reminder.title}
          </h3>
          <p className="text-sm text-muted-foreground">
            {reminder.description || reminder.title}
          </p>
          <div className="flex items-center gap-2 mt-2 flex-wrap">
            <span className="text-sm text-muted-foreground">
              {format(dueDate, 'd MMM yyyy', { locale: it })}
            </span>
            {reminder.amount && (
              <span className="text-sm font-medium text-expense">
                {formatCurrency(Number(reminder.amount))}
              </span>
            )}
            {reminder.categories && (
              <Badge variant="outline" className="text-xs">
                {reminder.categories.name}
              </Badge>
            )}
          </div>
        </div>

        {/* Actions */}
        <ReminderActions reminder={reminder} />
      </div>
    </motion.div>
  );
}
