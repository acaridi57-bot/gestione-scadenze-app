import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { 
  Plus, 
  TrendingUp, 
  TrendingDown, 
  Filter, 
  ArrowUpDown,
  Printer,
  Download,
  FileSpreadsheet,
  FileJson,
  Database,
  CalendarIcon,
  X,
  Upload,
  Volume2,
  VolumeX,
  Square,
  Loader2,
  Tag
} from 'lucide-react';
import { MainLayout } from '@/components/layout/MainLayout';
import { NavigationButtons } from '@/components/layout/NavigationButtons';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { useTransactions, Transaction } from '@/hooks/useTransactions';
import { useCategories } from '@/hooks/useCategories';
import { format, isAfter, isBefore, startOfDay, endOfDay } from 'date-fns';
import { it } from 'date-fns/locale';
import { AddTransactionDialog } from '@/components/transactions/AddTransactionDialog';
import { ImportTransactionsDialog } from '@/components/transactions/ImportTransactionsDialog';
import { TransactionActions } from '@/components/transactions/TransactionActions';
import { YearlyTransactionsChart } from '@/components/transactions/YearlyTransactionsChart';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { useTTS } from '@/hooks/useTTS';
import euroCoin from '@/assets/2-euro-coin.png';

type FilterType = 'all' | 'entrata' | 'uscita';
type SortOrder = 'date-desc' | 'date-asc' | 'amount-desc' | 'amount-asc';

export default function Transactions() {
  const { transactions, isLoading } = useTransactions();
  const { categories } = useCategories();
  const { speak, stop, isPlaying, isLoading: isTTSLoading } = useTTS();
  const [filter, setFilter] = useState<FilterType>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [sortOrder, setSortOrder] = useState<SortOrder>('date-desc');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [voiceEnabled, setVoiceEnabled] = useState(false);

  const handleVoiceToggle = () => {
    if (isPlaying) {
      stop();
      setVoiceEnabled(false);
      return;
    }

    if (filteredTransactions.length === 0) {
      toast.info('Nessuna transazione da leggere');
      return;
    }

    const recentTransactions = filteredTransactions.slice(0, 5);
    const totalEntrate = filteredTransactions
      .filter(t => t.type === 'entrata')
      .reduce((sum, t) => sum + Number(t.amount), 0);
    const totalUscite = filteredTransactions
      .filter(t => t.type === 'uscita')
      .reduce((sum, t) => sum + Number(t.amount), 0);

    const intro = `Hai ${filteredTransactions.length} transazioni. 
      Totale entrate: ${totalEntrate.toFixed(0)} euro. 
      Totale uscite: ${totalUscite.toFixed(0)} euro.`;

    const transactionDetails = recentTransactions.map(t => {
      const tipo = t.type === 'entrata' ? 'entrata' : 'uscita';
      const categoria = t.categories?.name || 'senza categoria';
      return `${tipo} di ${Number(t.amount).toFixed(0)} euro, ${categoria}`;
    }).join('. ');

    setVoiceEnabled(true);
    speak(`${intro} Ultime transazioni: ${transactionDetails}.`);
  };

  const filteredTransactions = useMemo(() => {
    let result = [...transactions];

    // Filter by type
    if (filter !== 'all') {
      result = result.filter(t => t.type === filter);
    }

    // Filter by category
    if (categoryFilter !== 'all') {
      result = result.filter(t => t.category_id === categoryFilter);
    }

    // Filter by date range
    if (startDate) {
      result = result.filter(t => !isBefore(new Date(t.date), startOfDay(startDate)));
    }
    if (endDate) {
      result = result.filter(t => !isAfter(new Date(t.date), endOfDay(endDate)));
    }

    // Sort
    result.sort((a, b) => {
      switch (sortOrder) {
        case 'date-desc':
          return new Date(b.date).getTime() - new Date(a.date).getTime();
        case 'date-asc':
          return new Date(a.date).getTime() - new Date(b.date).getTime();
        case 'amount-desc':
          return Number(b.amount) - Number(a.amount);
        case 'amount-asc':
          return Number(a.amount) - Number(b.amount);
        default:
          return 0;
      }
    });

    return result;
  }, [transactions, filter, categoryFilter, sortOrder, startDate, endDate]);

  const clearDateFilters = () => {
    setStartDate(undefined);
    setEndDate(undefined);
  };

  const clearAllFilters = () => {
    setFilter('all');
    setCategoryFilter('all');
    setStartDate(undefined);
    setEndDate(undefined);
  };

  const selectedCategoryName = categoryFilter === 'all' 
    ? 'Tutte le categorie' 
    : categories.find(c => c.id === categoryFilter)?.name || 'Categoria';

  const formatCurrency = (value: number, type: string) => {
    const formatted = new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR'
    }).format(value);
    return type === 'entrata' ? `+${formatted.replace('€', '').trim()} €` : `-${formatted.replace('€', '').replace('-', '').trim()} €`;
  };

  const formatCurrencySimple = (value: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR'
    }).format(value);
  };

  // Calcola totali per categoria
  const getCategoryTotals = () => {
    const totals: { [key: string]: { name: string; entrate: number; uscite: number; icon: string } } = {};
    
    filteredTransactions.forEach(t => {
      const categoryName = t.categories?.name || 'Altro';
      const categoryIcon = t.categories?.icon || '📁';
      
      if (!totals[categoryName]) {
        totals[categoryName] = { name: categoryName, entrate: 0, uscite: 0, icon: categoryIcon };
      }
      
      if (t.type === 'entrata') {
        totals[categoryName].entrate += Number(t.amount);
      } else {
        totals[categoryName].uscite += Number(t.amount);
      }
    });
    
    return Object.values(totals).sort((a, b) => 
      (b.entrate + b.uscite) - (a.entrate + a.uscite)
    );
  };

  const categoryTotals = getCategoryTotals();
  const totalEntrate = filteredTransactions.filter(t => t.type === 'entrata').reduce((sum, t) => sum + Number(t.amount), 0);
  const totalUscite = filteredTransactions.filter(t => t.type === 'uscita').reduce((sum, t) => sum + Number(t.amount), 0);

  const prepareExportData = () => {
    return filteredTransactions.map(t => ({
      data: format(new Date(t.date), 'dd/MM/yyyy'),
      tipo: t.type === 'entrata' ? 'Entrata' : 'Uscita',
      categoria: t.categories?.name || 'Altro',
      descrizione: t.description || '',
      importo: Number(t.amount),
      importo_pagato: Number(t.paid_amount) || 0,
      ricorrente: t.recurring === 'monthly' ? 'Mensile' : t.recurring === 'weekly' ? 'Settimanale' : 'No',
    }));
  };

  const handlePrint = () => {
    const printContent = `
      <html>
        <head>
          <title>Transazioni</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            h1 { color: #333; }
            h2 { color: #555; margin-top: 30px; }
            table { width: 100%; border-collapse: collapse; margin-top: 15px; }
            th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
            th { background-color: #f5f5f5; }
            .entrata { color: #22c55e; }
            .uscita { color: #ef4444; }
            .totals-section { margin-top: 30px; padding: 20px; background: #f9f9f9; border-radius: 8px; }
            .totals-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin-top: 15px; }
            .total-card { padding: 15px; background: white; border-radius: 8px; border: 1px solid #ddd; }
            .total-card h3 { margin: 0 0 10px 0; font-size: 14px; color: #666; }
            .total-card .amount { font-size: 18px; font-weight: bold; }
            .summary-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee; }
            .category-totals { margin-top: 20px; }
            .category-row { display: flex; justify-content: space-between; align-items: center; padding: 10px; background: white; margin: 5px 0; border-radius: 4px; border: 1px solid #eee; }
          </style>
        </head>
        <body>
          <h1>📊 Transazioni</h1>
          <p>Esportato il: ${format(new Date(), 'dd/MM/yyyy HH:mm')}</p>
          <p>Totale transazioni: ${filteredTransactions.length}</p>
          
          <div class="totals-section">
            <h2>💰 Riepilogo Generale</h2>
            <div class="totals-grid">
              <div class="total-card">
                <h3>Totale Entrate</h3>
                <div class="amount entrata">${formatCurrencySimple(totalEntrate)}</div>
              </div>
              <div class="total-card">
                <h3>Totale Uscite</h3>
                <div class="amount uscita">${formatCurrencySimple(totalUscite)}</div>
              </div>
              <div class="total-card">
                <h3>Saldo</h3>
                <div class="amount ${totalEntrate - totalUscite >= 0 ? 'entrata' : 'uscita'}">${formatCurrencySimple(totalEntrate - totalUscite)}</div>
              </div>
            </div>
            
            <div class="category-totals">
              <h2>📁 Totali per Categoria</h2>
              ${categoryTotals.map(cat => `
                <div class="category-row">
                  <span><strong>${cat.icon} ${cat.name}</strong></span>
                  <span>
                    ${cat.entrate > 0 ? `<span class="entrata">+${formatCurrencySimple(cat.entrate)}</span>` : ''}
                    ${cat.uscite > 0 ? `<span class="uscita"> -${formatCurrencySimple(cat.uscite)}</span>` : ''}
                  </span>
                </div>
              `).join('')}
            </div>
          </div>
          
          <h2>📋 Dettaglio Transazioni</h2>
          <table>
            <thead>
              <tr>
                <th>Data</th>
                <th>Tipo</th>
                <th>Categoria</th>
                <th>Descrizione</th>
                <th>Importo</th>
              </tr>
            </thead>
            <tbody>
              ${filteredTransactions.map(t => `
                <tr>
                  <td>${format(new Date(t.date), 'dd/MM/yyyy')}</td>
                  <td>${t.type === 'entrata' ? 'Entrata' : 'Uscita'}</td>
                  <td>${t.categories?.name || 'Altro'}</td>
                  <td>${t.description || ''}</td>
                  <td class="${t.type}">${formatCurrency(Number(t.amount), t.type)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </body>
      </html>
    `;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
    toast.success('Stampa avviata');
  };

  const handleExportCSV = () => {
    const data = prepareExportData();
    const headers = ['Data', 'Tipo', 'Categoria', 'Descrizione', 'Importo', 'Importo Pagato', 'Ricorrente'];
    
    // Dati transazioni
    let csvContent = headers.join(';') + '\n';
    csvContent += data.map(row => [
      row.data,
      row.tipo,
      row.categoria,
      `"${row.descrizione}"`,
      row.importo.toFixed(2).replace('.', ','),
      row.importo_pagato.toFixed(2).replace('.', ','),
      row.ricorrente
    ].join(';')).join('\n');
    
    // Aggiungi totali generali
    csvContent += '\n\n--- RIEPILOGO GENERALE ---\n';
    csvContent += `Totale Entrate;${totalEntrate.toFixed(2).replace('.', ',')}\n`;
    csvContent += `Totale Uscite;${totalUscite.toFixed(2).replace('.', ',')}\n`;
    csvContent += `Saldo;${(totalEntrate - totalUscite).toFixed(2).replace('.', ',')}\n`;
    
    // Aggiungi totali per categoria
    csvContent += '\n--- TOTALI PER CATEGORIA ---\n';
    csvContent += 'Categoria;Entrate;Uscite;Totale\n';
    categoryTotals.forEach(cat => {
      csvContent += `${cat.name};${cat.entrate.toFixed(2).replace('.', ',')};${cat.uscite.toFixed(2).replace('.', ',')};${(cat.entrate - cat.uscite).toFixed(2).replace('.', ',')}\n`;
    });
    
    downloadFile(csvContent, 'transazioni.csv', 'text/csv;charset=utf-8');
    toast.success('CSV esportato con totali per categoria');
  };

  const handleExportJSON = () => {
    const data = prepareExportData();
    const exportData = {
      esportato_il: format(new Date(), 'dd/MM/yyyy HH:mm'),
      totale_transazioni: filteredTransactions.length,
      riepilogo: {
        totale_entrate: totalEntrate,
        totale_uscite: totalUscite,
        saldo: totalEntrate - totalUscite
      },
      totali_per_categoria: categoryTotals.map(cat => ({
        categoria: cat.name,
        icona: cat.icon,
        entrate: cat.entrate,
        uscite: cat.uscite,
        saldo: cat.entrate - cat.uscite
      })),
      transazioni: data
    };
    const jsonContent = JSON.stringify(exportData, null, 2);
    downloadFile(jsonContent, 'transazioni.json', 'application/json');
    toast.success('JSON esportato con totali per categoria');
  };

  const handleExportSQL = () => {
    const data = prepareExportData();
    let sqlContent = `-- Transazioni esportate il ${format(new Date(), 'dd/MM/yyyy HH:mm')}\n`;
    sqlContent += `-- Totale: ${data.length} record\n`;
    sqlContent += `-- Totale Entrate: ${totalEntrate.toFixed(2)} EUR\n`;
    sqlContent += `-- Totale Uscite: ${totalUscite.toFixed(2)} EUR\n`;
    sqlContent += `-- Saldo: ${(totalEntrate - totalUscite).toFixed(2)} EUR\n\n`;
    
    // Commenti con totali per categoria
    sqlContent += `-- TOTALI PER CATEGORIA:\n`;
    categoryTotals.forEach(cat => {
      sqlContent += `-- ${cat.name}: Entrate ${cat.entrate.toFixed(2)}, Uscite ${cat.uscite.toFixed(2)}, Saldo ${(cat.entrate - cat.uscite).toFixed(2)}\n`;
    });
    sqlContent += '\n';
    
    const sqlStatements = data.map(row => 
      `INSERT INTO transazioni (data, tipo, categoria, descrizione, importo, importo_pagato, ricorrente) VALUES ('${row.data}', '${row.tipo}', '${row.categoria}', '${row.descrizione.replace(/'/g, "''")}', ${row.importo}, ${row.importo_pagato}, '${row.ricorrente}');`
    ).join('\n');
    
    sqlContent += sqlStatements;
    downloadFile(sqlContent, 'transazioni.sql', 'text/plain');
    toast.success('SQL esportato');
  };

  const handleExportExcel = () => {
    // Export as CSV with Excel-compatible format
    const data = prepareExportData();
    const headers = ['Data', 'Tipo', 'Categoria', 'Descrizione', 'Importo', 'Importo Pagato', 'Ricorrente'];
    
    // BOM for Excel to recognize UTF-8
    const BOM = '\uFEFF';
    let excelContent = BOM + headers.join('\t') + '\n';
    excelContent += data.map(row => [
      row.data,
      row.tipo,
      row.categoria,
      row.descrizione,
      row.importo.toFixed(2),
      row.importo_pagato.toFixed(2),
      row.ricorrente
    ].join('\t')).join('\n');
    
    // Aggiungi righe vuote e totali generali
    excelContent += '\n\n\nRIEPILOGO GENERALE\n';
    excelContent += `Totale Entrate\t${totalEntrate.toFixed(2)}\n`;
    excelContent += `Totale Uscite\t${totalUscite.toFixed(2)}\n`;
    excelContent += `Saldo\t${(totalEntrate - totalUscite).toFixed(2)}\n`;
    
    // Aggiungi totali per categoria
    excelContent += '\n\nTOTALI PER CATEGORIA\n';
    excelContent += 'Categoria\tEntrate\tUscite\tSaldo\n';
    categoryTotals.forEach(cat => {
      excelContent += `${cat.name}\t${cat.entrate.toFixed(2)}\t${cat.uscite.toFixed(2)}\t${(cat.entrate - cat.uscite).toFixed(2)}\n`;
    });
    
    downloadFile(excelContent, 'transazioni.xls', 'application/vnd.ms-excel;charset=utf-8');
    toast.success('Excel esportato con totali per categoria');
  };

  const handleExportPDF = () => {
    // Create a printable version and suggest saving as PDF
    const printContent = `
      <html>
        <head>
          <title>Transazioni - PDF</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            h1 { color: #333; margin-bottom: 5px; }
            h2 { color: #555; margin-top: 25px; font-size: 16px; }
            .subtitle { color: #666; margin-bottom: 20px; }
            table { width: 100%; border-collapse: collapse; margin-top: 15px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 11px; }
            th { background-color: #f5f5f5; font-weight: bold; }
            .entrata { color: #22c55e; }
            .uscita { color: #ef4444; }
            .totals-section { margin-top: 25px; padding: 15px; background: #f9f9f9; border-radius: 8px; page-break-inside: avoid; }
            .totals-grid { display: flex; gap: 20px; margin: 15px 0; }
            .total-box { flex: 1; padding: 10px; background: white; border: 1px solid #ddd; border-radius: 4px; text-align: center; }
            .total-box .label { font-size: 11px; color: #666; }
            .total-box .value { font-size: 16px; font-weight: bold; margin-top: 5px; }
            .category-table { margin-top: 15px; }
            .category-table th, .category-table td { padding: 6px 10px; }
          </style>
        </head>
        <body>
          <h1>📊 Report Transazioni</h1>
          <p class="subtitle">Esportato il: ${format(new Date(), 'dd/MM/yyyy HH:mm')} | Totale: ${filteredTransactions.length} transazioni</p>
          
          <div class="totals-section">
            <h2>💰 Riepilogo Generale</h2>
            <div class="totals-grid">
              <div class="total-box">
                <div class="label">Totale Entrate</div>
                <div class="value entrata">${formatCurrencySimple(totalEntrate)}</div>
              </div>
              <div class="total-box">
                <div class="label">Totale Uscite</div>
                <div class="value uscita">${formatCurrencySimple(totalUscite)}</div>
              </div>
              <div class="total-box">
                <div class="label">Saldo</div>
                <div class="value ${totalEntrate - totalUscite >= 0 ? 'entrata' : 'uscita'}">${formatCurrencySimple(totalEntrate - totalUscite)}</div>
              </div>
            </div>
            
            <h2>📁 Totali per Categoria</h2>
            <table class="category-table">
              <thead>
                <tr>
                  <th>Categoria</th>
                  <th style="text-align:right">Entrate</th>
                  <th style="text-align:right">Uscite</th>
                  <th style="text-align:right">Saldo</th>
                </tr>
              </thead>
              <tbody>
                ${categoryTotals.map(cat => `
                  <tr>
                    <td>${cat.icon} ${cat.name}</td>
                    <td style="text-align:right" class="entrata">${cat.entrate > 0 ? formatCurrencySimple(cat.entrate) : '-'}</td>
                    <td style="text-align:right" class="uscita">${cat.uscite > 0 ? formatCurrencySimple(cat.uscite) : '-'}</td>
                    <td style="text-align:right" class="${cat.entrate - cat.uscite >= 0 ? 'entrata' : 'uscita'}">${formatCurrencySimple(cat.entrate - cat.uscite)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
          
          <h2>📋 Dettaglio Transazioni</h2>
          <table>
            <thead>
              <tr>
                <th>Data</th>
                <th>Tipo</th>
                <th>Categoria</th>
                <th>Descrizione</th>
                <th style="text-align:right">Importo</th>
              </tr>
            </thead>
            <tbody>
              ${filteredTransactions.map(t => `
                <tr>
                  <td>${format(new Date(t.date), 'dd/MM/yyyy')}</td>
                  <td>${t.type === 'entrata' ? 'Entrata' : 'Uscita'}</td>
                  <td>${t.categories?.name || 'Altro'}</td>
                  <td>${t.description || ''}</td>
                  <td style="text-align:right" class="${t.type}">${formatCurrency(Number(t.amount), t.type)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </body>
      </html>
    `;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      toast.info('Usa "Salva come PDF" nel dialogo di stampa');
      setTimeout(() => printWindow.print(), 500);
    }
  };

  const downloadFile = (content: string, filename: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const getSortLabel = (order: SortOrder) => {
    switch (order) {
      case 'date-desc':
        return 'Data ↓ (decrescente)';
      case 'date-asc':
        return 'Data ↑ (crescente)';
      case 'amount-desc':
        return 'Importo ↓';
      case 'amount-asc':
        return 'Importo ↑';
    }
  };

  return (
    <MainLayout>
      <div className="p-4 md:p-6 max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="coin-container">
              <div className="banknote-shine coin-rotate w-10 h-10 rounded-full">
                <img src={euroCoin} alt="Euro" className="w-10 h-10 object-contain" />
              </div>
            </div>
            <motion.h1
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-2xl md:text-3xl font-bold text-[#067d1c]"
            >
              Transazioni
            </motion.h1>
          </div>
          
          <div className="flex items-center gap-2">
            <NavigationButtons />
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleVoiceToggle}
              disabled={isTTSLoading}
              className="gap-2 text-primary border-primary/30 hover:bg-primary/10"
            >
              {isTTSLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : isPlaying ? (
                <Square className="w-4 h-4" />
              ) : voiceEnabled ? (
                <Volume2 className="w-4 h-4" />
              ) : (
                <VolumeX className="w-4 h-4" />
              )}
              {isTTSLoading ? 'Carico...' : isPlaying ? 'Stop' : 'Leggi'}
            </Button>
            <Button 
              onClick={() => setDialogOpen(true)}
              className="gradient-primary text-primary-foreground shadow-glow"
            >
              <Plus className="w-4 h-4 mr-2" />
              Aggiungi
            </Button>
          </div>
        </div>

        {/* Filters and Export */}
        <div className="flex flex-col gap-4 mb-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-2 flex-wrap">
              {/* Filter Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-2 text-primary border-primary/30 hover:bg-primary/10">
                    <Filter className="w-4 h-4" />
                    {filter === 'all' ? 'Tutte' : filter === 'entrata' ? 'Entrate' : 'Uscite'}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setFilter('all')}>
                    Tutte
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setFilter('entrata')}>
                    Entrate
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setFilter('uscita')}>
                    Uscite
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Sort Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-2 text-primary border-primary/30 hover:bg-primary/10">
                    <ArrowUpDown className="w-4 h-4" />
                    {getSortLabel(sortOrder)}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setSortOrder('date-desc')}>
                    Data ↓ (decrescente)
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSortOrder('date-asc')}>
                    Data ↑ (crescente)
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSortOrder('amount-desc')}>
                    Importo ↓
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSortOrder('amount-asc')}>
                    Importo ↑
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Category Filter Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-2 text-primary border-primary/30 hover:bg-primary/10">
                    <Tag className="w-4 h-4" />
                    {selectedCategoryName}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="max-h-[300px] overflow-y-auto">
                  <DropdownMenuItem onClick={() => setCategoryFilter('all')}>
                    Tutte le categorie
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  {categories.map((category) => (
                    <DropdownMenuItem 
                      key={category.id} 
                      onClick={() => setCategoryFilter(category.id)}
                    >
                      <span className="mr-2">{category.icon}</span>
                      {category.name}
                      <Badge 
                        variant="outline" 
                        className={cn(
                          "ml-2 text-xs",
                          category.type === 'entrata' ? 'text-income border-income/30' : 'text-expense border-expense/30'
                        )}
                      >
                        {category.type === 'entrata' ? 'Entrata' : 'Uscita'}
                      </Badge>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Clear All Filters */}
              {(filter !== 'all' || categoryFilter !== 'all' || startDate || endDate) && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearAllFilters}
                  className="h-8 px-2 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4 mr-1" />
                  Reset filtri
                </Button>
              )}
            </div>

            {/* Date Range Filters */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm text-muted-foreground">Dal:</span>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className={cn(
                      "w-[130px] justify-start text-left font-normal text-primary border-primary/30 hover:bg-primary/10",
                      !startDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4 text-[#067d1c]" />
                    {startDate ? format(startDate, "dd/MM/yyyy") : "Seleziona"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={startDate}
                    onSelect={setStartDate}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>

              <span className="text-sm text-muted-foreground">Al:</span>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className={cn(
                      "w-[130px] justify-start text-left font-normal text-primary border-primary/30 hover:bg-primary/10",
                      !endDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4 text-[#067d1c]" />
                    {endDate ? format(endDate, "dd/MM/yyyy") : "Seleziona"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={endDate}
                    onSelect={setEndDate}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>

              {(startDate || endDate) && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearDateFilters}
                  className="h-8 px-2"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>

          {/* Import/Export Buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <Button variant="outline" size="sm" className="text-primary border-primary/30 hover:bg-primary/10" onClick={() => setImportDialogOpen(true)}>
              <Upload className="w-4 h-4 mr-2" />
              Importa
            </Button>
            <Button variant="outline" size="sm" className="text-primary border-primary/30 hover:bg-primary/10" onClick={handlePrint}>
              <Printer className="w-4 h-4 mr-2" />
              Stampa
            </Button>
            <Button variant="outline" size="sm" className="text-primary border-primary/30 hover:bg-primary/10" onClick={handleExportCSV}>
              <Download className="w-4 h-4 mr-2" />
              CSV
            </Button>
            <Button variant="outline" size="sm" className="text-primary border-primary/30 hover:bg-primary/10" onClick={handleExportPDF}>
              <Download className="w-4 h-4 mr-2" />
              PDF
            </Button>
            <Button variant="outline" size="sm" className="text-primary border-primary/30 hover:bg-primary/10" onClick={handleExportExcel}>
              <FileSpreadsheet className="w-4 h-4 mr-2" />
              Excel
            </Button>
            <Button variant="outline" size="sm" className="text-primary border-primary/30 hover:bg-primary/10" onClick={handleExportJSON}>
              <FileJson className="w-4 h-4 mr-2" />
              JSON
            </Button>
            <Button variant="outline" size="sm" className="text-primary border-primary/30 hover:bg-primary/10" onClick={handleExportSQL}>
              <Database className="w-4 h-4 mr-2" />
              SQL
            </Button>
          </div>
        </div>

        {/* Yearly Chart */}
        <YearlyTransactionsChart transactions={transactions} />

        {/* Transactions List */}
        <Card className="shadow-card">
          <CardContent className="p-4 md:p-6">
            <div className="text-sm text-muted-foreground mb-4">
              {filteredTransactions.length} Transazioni
            </div>

            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : filteredTransactions.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                Nessuna transazione trovata
              </div>
            ) : (
              <div className="space-y-3">
                {filteredTransactions.map((transaction, index) => (
                  <TransactionItem 
                    key={transaction.id} 
                    transaction={transaction}
                    formatCurrency={formatCurrency}
                    delay={index * 0.05}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <AddTransactionDialog open={dialogOpen} onOpenChange={setDialogOpen} />
        <ImportTransactionsDialog open={importDialogOpen} onOpenChange={setImportDialogOpen} />
      </div>
    </MainLayout>
  );
}

interface TransactionItemProps {
  transaction: Transaction;
  formatCurrency: (value: number, type: string) => string;
  delay: number;
}

function TransactionItem({ transaction, formatCurrency, delay }: TransactionItemProps) {
  const isIncome = transaction.type === 'entrata';
  const isPaid = transaction.is_partial && Number(transaction.paid_amount) >= Number(transaction.amount);
  const isRecurring = transaction.recurring && transaction.recurring !== 'none';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="flex items-center gap-4 p-4 rounded-xl bg-secondary/30 hover:bg-secondary/50 transition-colors"
    >
      {/* Icon */}
      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
        isIncome ? 'bg-income/10' : 'bg-expense/10'
      }`}>
        {isIncome ? (
          <TrendingUp className="w-5 h-5 text-income" />
        ) : (
          <TrendingDown className="w-5 h-5 text-expense" />
        )}
      </div>

      {/* Details */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-medium text-foreground">
            {transaction.categories?.name || 'Altro'}
          </span>
          {isRecurring && (
            <Badge variant="outline" className="text-xs">
              Auto
            </Badge>
          )}
          {isPaid && (
            <Badge variant="outline" className="text-xs text-income border-income/30">
              ✓ Saldato
            </Badge>
          )}
        </div>
        <p className="text-sm text-muted-foreground truncate">
          {transaction.description || 'Nessuna descrizione'}
        </p>
        <p className="text-xs text-muted-foreground">
          {format(new Date(transaction.date), 'd MMMM yyyy', { locale: it })}
        </p>
      </div>

      {/* Amount */}
      <div className="text-right mr-2">
        <span className={`text-lg font-semibold ${
          isIncome ? 'text-income' : 'text-expense'
        }`}>
          {formatCurrency(Number(transaction.amount), transaction.type)}
        </span>
      </div>

      {/* Actions */}
      <TransactionActions transaction={transaction} />
    </motion.div>
  );
}
