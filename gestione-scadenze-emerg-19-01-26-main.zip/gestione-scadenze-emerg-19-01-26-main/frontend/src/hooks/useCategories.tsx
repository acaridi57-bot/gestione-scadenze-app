import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';

export interface Category {
  id: string;
  user_id: string | null;
  name: string;
  type: 'entrata' | 'uscita';
  icon: string;
  color: string;
  is_default: boolean;
  created_at: string;
}

export function useCategories() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: categories = [], isLoading } = useQuery({
    queryKey: ['categories', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('name');
      
      if (error) throw error;
      return data as Category[];
    },
    enabled: !!user
  });

  const addCategory = useMutation({
    mutationFn: async (category: Omit<Category, 'id' | 'created_at' | 'user_id' | 'is_default'>) => {
      const { data, error } = await supabase
        .from('categories')
        .insert({
          ...category,
          user_id: user?.id,
          is_default: false
        })
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
    }
  });

  const updateCategory = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<Category> & { id: string }) => {
      const { data, error } = await supabase
        .from('categories')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
    }
  });

  const deleteCategory = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('categories')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
    }
  });

  const incomeCategories = categories.filter(c => c.type === 'entrata');
  const expenseCategories = categories.filter(c => c.type === 'uscita');

  return {
    categories,
    incomeCategories,
    expenseCategories,
    isLoading,
    addCategory,
    updateCategory,
    deleteCategory
  };
}
