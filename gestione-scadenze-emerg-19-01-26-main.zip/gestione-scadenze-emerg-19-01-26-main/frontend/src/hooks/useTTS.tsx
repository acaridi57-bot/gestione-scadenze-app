import { useState, useCallback, useRef, useEffect } from 'react';
import { toast } from 'sonner';

export function useTTS() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Load voices when available
  useEffect(() => {
    const loadVoices = () => {
      const availableVoices = window.speechSynthesis?.getVoices() || [];
      setVoices(availableVoices);
    };

    if ('speechSynthesis' in window) {
      loadVoices();
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }

    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.onvoiceschanged = null;
      }
    };
  }, []);

  const speak = useCallback(async (text: string) => {
    if (!text.trim()) {
      toast.error('Nessun testo da leggere');
      return;
    }

    // Check if Web Speech API is supported
    if (!('speechSynthesis' in window)) {
      toast.error('Il tuo browser non supporta la sintesi vocale');
      return;
    }

    // Stop current speech if playing
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
    }

    setIsLoading(true);
    setIsPlaying(false);

    try {
      const utterance = new SpeechSynthesisUtterance(text);
      utteranceRef.current = utterance;

      // Set Italian language
      utterance.lang = 'it-IT';
      utterance.rate = 0.9;
      utterance.pitch = 1;
      utterance.volume = 1;

      // Try to find an Italian voice
      const currentVoices = voices.length > 0 ? voices : window.speechSynthesis.getVoices();
      const italianVoice = currentVoices.find(voice => 
        voice.lang.startsWith('it') || voice.lang.includes('IT')
      );
      if (italianVoice) {
        utterance.voice = italianVoice;
      }

      utterance.onstart = () => {
        setIsLoading(false);
        setIsPlaying(true);
      };

      utterance.onend = () => {
        setIsPlaying(false);
        utteranceRef.current = null;
      };

      utterance.onerror = (event) => {
        console.error('Speech error:', event.error);
        setIsPlaying(false);
        setIsLoading(false);
        utteranceRef.current = null;
        if (event.error !== 'canceled' && event.error !== 'interrupted') {
          toast.error('Errore nella sintesi vocale');
        }
      };

      // Small delay to ensure voices are loaded
      setTimeout(() => {
        window.speechSynthesis.speak(utterance);
      }, 100);
      
    } catch (error) {
      console.error('TTS error:', error);
      toast.error('Errore nella sintesi vocale');
      setIsLoading(false);
    }
  }, [voices]);

  const stop = useCallback(() => {
    if ('speechSynthesis' in window && window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
    }
    setIsPlaying(false);
    setIsLoading(false);
    utteranceRef.current = null;
  }, []);

  return {
    speak,
    stop,
    isPlaying,
    isLoading,
  };
}
