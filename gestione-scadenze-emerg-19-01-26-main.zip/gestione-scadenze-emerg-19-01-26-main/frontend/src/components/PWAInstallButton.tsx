import { useState } from 'react';
import { Download, Smartphone, X, Share, Plus, Trash2, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { usePWAInstall } from '@/hooks/usePWAInstall';
import { toast } from 'sonner';

interface PWAInstallButtonProps {
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'default' | 'sm' | 'lg' | 'icon';
  className?: string;
  showText?: boolean;
}

export function PWAInstallButton({ 
  variant = 'default', 
  size = 'default',
  className = '',
  showText = true 
}: PWAInstallButtonProps) {
  const { isInstallable, isInstalled, isIOS, promptInstall } = usePWAInstall();
  const [showIOSDialog, setShowIOSDialog] = useState(false);

  const handleInstallClick = async () => {
    if (isIOS) {
      setShowIOSDialog(true);
      return;
    }

    if (isInstallable) {
      const installed = await promptInstall();
      if (installed) {
        toast.success('App installata con successo!');
      }
    } else {
      // Fallback: show instructions
      toast.info('Usa il menu del browser per installare l\'app');
    }
  };

  // Don't show if already installed
  if (isInstalled) {
    return null;
  }

  return (
    <>
      <Button
        variant={variant}
        size={size}
        onClick={handleInstallClick}
        className={className}
      >
        <Download className="w-4 h-4" />
        {showText && <span className="ml-2">Installa App</span>}
      </Button>

      {/* iOS Installation Instructions Dialog */}
      <Dialog open={showIOSDialog} onOpenChange={setShowIOSDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-primary" />
              Installa su iPhone/iPad
            </DialogTitle>
            <DialogDescription>
              Segui questi passaggi per installare l'app sul tuo dispositivo iOS
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold">
                1
              </div>
              <div>
                <p className="font-medium">Tocca il pulsante Condividi</p>
                <p className="text-sm text-muted-foreground">
                  Cerca l'icona <Share className="w-4 h-4 inline mx-1" /> nella barra di Safari
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold">
                2
              </div>
              <div>
                <p className="font-medium">Scorri e tocca "Aggiungi a Home"</p>
                <p className="text-sm text-muted-foreground">
                  Cerca l'opzione <Plus className="w-4 h-4 inline mx-1" /> Aggiungi a schermata Home
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold">
                3
              </div>
              <div>
                <p className="font-medium">Conferma l'installazione</p>
                <p className="text-sm text-muted-foreground">
                  Tocca "Aggiungi" in alto a destra per completare
                </p>
              </div>
            </div>
          </div>

          <Button onClick={() => setShowIOSDialog(false)} className="w-full">
            Ho capito
          </Button>
        </DialogContent>
      </Dialog>
    </>
  );
}

// Componente per disinstallare l'app
interface PWAUninstallButtonProps {
  variant?: 'default' | 'outline' | 'ghost' | 'destructive';
  size?: 'default' | 'sm' | 'lg';
  className?: string;
}

export function PWAUninstallButton({ 
  variant = 'outline', 
  size = 'default',
  className = ''
}: PWAUninstallButtonProps) {
  const { isInstalled, isIOS } = usePWAInstall();
  const [showUninstallDialog, setShowUninstallDialog] = useState(false);

  // Detect if running as standalone PWA
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
  
  // Detect Android
  const isAndroid = /Android/i.test(navigator.userAgent);
  
  // Detect Chrome
  const isChrome = /Chrome/i.test(navigator.userAgent) && !/Edge|Edg/i.test(navigator.userAgent);

  if (!isInstalled && !isStandalone) {
    return null;
  }

  return (
    <>
      <Button
        variant={variant}
        size={size}
        onClick={() => setShowUninstallDialog(true)}
        className={className}
      >
        <Trash2 className="w-4 h-4 mr-2" />
        Disinstalla App
      </Button>

      {/* Uninstall Instructions Dialog */}
      <Dialog open={showUninstallDialog} onOpenChange={setShowUninstallDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <Trash2 className="w-5 h-5" />
              Disinstalla Gestione Scadenze
            </DialogTitle>
            <DialogDescription>
              Segui questi passaggi per rimuovere l'app dal tuo dispositivo
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {isIOS ? (
              // iOS instructions
              <>
                <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-destructive text-destructive-foreground text-sm font-bold">
                    1
                  </div>
                  <div>
                    <p className="font-medium">Vai alla schermata Home</p>
                    <p className="text-sm text-muted-foreground">
                      Trova l'icona di Gestione Scadenze
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-destructive text-destructive-foreground text-sm font-bold">
                    2
                  </div>
                  <div>
                    <p className="font-medium">Tieni premuto sull'icona</p>
                    <p className="text-sm text-muted-foreground">
                      Attendi che appaia il menu contestuale
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-destructive text-destructive-foreground text-sm font-bold">
                    3
                  </div>
                  <div>
                    <p className="font-medium">Tocca "Rimuovi segnalibro"</p>
                    <p className="text-sm text-muted-foreground">
                      Oppure "Elimina segnalibro" per confermare
                    </p>
                  </div>
                </div>
              </>
            ) : isAndroid ? (
              // Android instructions
              <>
                <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-destructive text-destructive-foreground text-sm font-bold">
                    1
                  </div>
                  <div>
                    <p className="font-medium">Vai alle Impostazioni del telefono</p>
                    <p className="text-sm text-muted-foreground">
                      Apri Impostazioni → App o Applicazioni
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-destructive text-destructive-foreground text-sm font-bold">
                    2
                  </div>
                  <div>
                    <p className="font-medium">Trova "Gestione Scadenze"</p>
                    <p className="text-sm text-muted-foreground">
                      Cerca nell'elenco delle app installate
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-destructive text-destructive-foreground text-sm font-bold">
                    3
                  </div>
                  <div>
                    <p className="font-medium">Tocca "Disinstalla"</p>
                    <p className="text-sm text-muted-foreground">
                      Conferma per rimuovere l'app
                    </p>
                  </div>
                </div>
              </>
            ) : (
              // Desktop/Chrome instructions
              <>
                <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-destructive text-destructive-foreground text-sm font-bold">
                    1
                  </div>
                  <div>
                    <p className="font-medium">Clicca sull'icona ⋮ nel browser</p>
                    <p className="text-sm text-muted-foreground">
                      In alto a destra nella finestra dell'app
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-destructive text-destructive-foreground text-sm font-bold">
                    2
                  </div>
                  <div>
                    <p className="font-medium">Seleziona "Disinstalla Gestione Scadenze"</p>
                    <p className="text-sm text-muted-foreground">
                      Oppure "Rimuovi" o "Elimina"
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-destructive text-destructive-foreground text-sm font-bold">
                    3
                  </div>
                  <div>
                    <p className="font-medium">Conferma la disinstallazione</p>
                    <p className="text-sm text-muted-foreground">
                      Clicca "Rimuovi" per completare
                    </p>
                  </div>
                </div>
              </>
            )}

            <div className="flex items-start gap-2 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
              <Info className="w-5 h-5 text-yellow-600 dark:text-yellow-400 mt-0.5" />
              <p className="text-sm text-yellow-700 dark:text-yellow-300">
                <strong>Nota:</strong> I tuoi dati rimarranno salvati nel cloud. Potrai accedere nuovamente dal browser o reinstallando l'app.
              </p>
            </div>
          </div>

          <Button onClick={() => setShowUninstallDialog(false)} className="w-full">
            Ho capito
          </Button>
        </DialogContent>
      </Dialog>
    </>
  );
}
