import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Bell, Calendar, Check, AlertCircle } from 'lucide-react';
import { format, differenceInDays, parseISO } from 'date-fns';
import { it } from 'date-fns/locale';
import { Reminder } from '@/hooks/useReminders';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface UpcomingRemindersProps {
  reminders: Reminder[];
  onToggleComplete: (id: string, completed: boolean) => void;
}

export function UpcomingReminders({ reminders, onToggleComplete }: UpcomingRemindersProps) {
  const upcomingReminders = useMemo(() => {
    const today = new Date();
    return reminders
      .filter(r => !r.completed)
      .filter(r => differenceInDays(parseISO(r.due_date), today) <= 7)
      .slice(0, 5);
  }, [reminders]);

  const getDaysLabel = (dueDate: string) => {
    const days = differenceInDays(parseISO(dueDate), new Date());
    if (days < 0) return { label: 'Scaduto', color: 'text-expense' };
    if (days === 0) return { label: 'Oggi', color: 'text-warning' };
    if (days === 1) return { label: 'Domani', color: 'text-warning' };
    return { label: `${days} giorni`, color: 'text-muted-foreground' };
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4, duration: 0.4 }}
      className="glass rounded-2xl p-5 shadow-card"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-[#067d1c] flex items-center gap-2">
          <Bell className="w-5 h-5 text-[#067d1c]" />
          Prossime Scadenze
        </h3>
      </div>

      {upcomingReminders.length === 0 ? (
        <div className="text-center py-8">
          <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-muted flex items-center justify-center">
            <Check className="w-6 h-6 text-muted-foreground" />
          </div>
          <p className="text-muted-foreground text-sm">Nessuna scadenza imminente</p>
        </div>
      ) : (
        <div className="space-y-3">
          {upcomingReminders.map((reminder, index) => {
            const { label, color } = getDaysLabel(reminder.due_date);
            const isOverdue = differenceInDays(parseISO(reminder.due_date), new Date()) < 0;

            return (
              <motion.div
                key={reminder.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 * index }}
                className={cn(
                  'flex items-center justify-between p-3 rounded-xl bg-secondary/50',
                  isOverdue && 'border border-expense/30'
                )}
              >
                <div className="flex items-center gap-3">
                  {isOverdue && <AlertCircle className="w-4 h-4 text-expense" />}
                  <div>
                    <p className="text-sm font-medium text-foreground">{reminder.title}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <Calendar className="w-3 h-3 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground">
                        {format(parseISO(reminder.due_date), 'd MMM', { locale: it })}
                      </span>
                      <span className={cn('text-xs font-medium', color)}>
                        {label}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {reminder.amount && (
                    <span className="text-sm font-semibold text-foreground">
                      €{Number(reminder.amount).toFixed(2)}
                    </span>
                  )}
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onToggleComplete(reminder.id, true)}
                    className="h-8 w-8 p-0"
                  >
                    <Check className="w-4 h-4" />
                  </Button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </motion.div>
  );
}
