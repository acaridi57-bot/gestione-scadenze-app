import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { CalendarIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Transaction, useTransactions } from '@/hooks/useTransactions';
import { useCategories } from '@/hooks/useCategories';
import { toast } from 'sonner';

const formSchema = z.object({
  type: z.enum(['entrata', 'uscita']),
  amount: z.string().min(1, 'Inserisci un importo'),
  description: z.string().optional(),
  category_id: z.string().optional(),
  date: z.date(),
  recurring: z.enum(['none', 'weekly', 'monthly']),
});

type FormData = z.infer<typeof formSchema>;

interface EditTransactionDialogProps {
  transaction: Transaction;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function EditTransactionDialog({ transaction, open, onOpenChange }: EditTransactionDialogProps) {
  const { updateTransaction } = useTransactions();
  const { incomeCategories, expenseCategories } = useCategories();
  const [activeTab, setActiveTab] = useState<'entrata' | 'uscita'>(transaction.type);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      type: transaction.type,
      amount: transaction.amount.toString(),
      description: transaction.description || '',
      category_id: transaction.category_id || '',
      date: new Date(transaction.date),
      recurring: transaction.recurring || 'none',
    },
  });

  useEffect(() => {
    if (open) {
      setActiveTab(transaction.type);
      form.reset({
        type: transaction.type,
        amount: transaction.amount.toString(),
        description: transaction.description || '',
        category_id: transaction.category_id || '',
        date: new Date(transaction.date),
        recurring: transaction.recurring || 'none',
      });
    }
  }, [open, transaction, form]);

  const categories = activeTab === 'entrata' ? incomeCategories : expenseCategories;

  const onSubmit = async (data: FormData) => {
    try {
      await updateTransaction.mutateAsync({
        id: transaction.id,
        type: activeTab,
        amount: parseFloat(data.amount),
        description: data.description || null,
        category_id: data.category_id || null,
        date: format(data.date, 'yyyy-MM-dd'),
        recurring: data.recurring,
      });
      
      toast.success('Transazione aggiornata');
      onOpenChange(false);
    } catch (error) {
      toast.error('Errore durante il salvataggio');
    }
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value as 'entrata' | 'uscita');
    form.setValue('type', value as 'entrata' | 'uscita');
    form.setValue('category_id', '');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Modifica Transazione</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <Tabs value={activeTab} onValueChange={handleTabChange}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="uscita" className="data-[state=active]:bg-expense data-[state=active]:text-expense-foreground">
                  Uscita
                </TabsTrigger>
                <TabsTrigger value="entrata" className="data-[state=active]:bg-income data-[state=active]:text-income-foreground">
                  Entrata
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Importo (€)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Categoria</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleziona categoria" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descrizione</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Descrizione opzionale..."
                      className="resize-none"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Data</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          className={cn(
                            'w-full pl-3 text-left font-normal text-primary border-primary/30 hover:bg-primary/10',
                            !field.value && 'text-muted-foreground'
                          )}
                        >
                          {field.value ? (
                            format(field.value, 'dd/MM/yyyy')
                          ) : (
                            <span>Seleziona data</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="recurring"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Ricorrenza</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="none">Nessuna</SelectItem>
                      <SelectItem value="weekly">Settimanale</SelectItem>
                      <SelectItem value="monthly">Mensile</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                className="flex-1 text-primary border-primary/30 hover:bg-primary/10"
                onClick={() => onOpenChange(false)}
              >
                Annulla
              </Button>
              <Button
                type="submit"
                className={cn(
                  'flex-1',
                  activeTab === 'entrata' 
                    ? 'bg-income hover:bg-income/90' 
                    : 'bg-expense hover:bg-expense/90'
                )}
                disabled={updateTransaction.isPending}
              >
                {updateTransaction.isPending ? 'Salvando...' : 'Salva'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
