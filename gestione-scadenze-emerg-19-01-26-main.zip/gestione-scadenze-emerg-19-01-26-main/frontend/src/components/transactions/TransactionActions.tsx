import { useState } from 'react';
import { 
  Pencil, 
  Trash2,
  Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Transaction, useTransactions } from '@/hooks/useTransactions';
import { toast } from 'sonner';
import { EditTransactionDialog } from './EditTransactionDialog';

interface TransactionActionsProps {
  transaction: Transaction;
}

export function TransactionActions({ transaction }: TransactionActionsProps) {
  const { updateTransaction, deleteTransaction } = useTransactions();
  
  const [editOpen, setEditOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);

  const isPaid = transaction.is_partial && Number(transaction.paid_amount) >= Number(transaction.amount);

  const handleDelete = async () => {
    try {
      await deleteTransaction.mutateAsync(transaction.id);
      toast.success('Transazione eliminata');
      setDeleteOpen(false);
    } catch (error) {
      toast.error('Errore durante l\'eliminazione');
    }
  };

  const handleTogglePaid = async () => {
    try {
      if (isPaid) {
        // Unmark as paid
        await updateTransaction.mutateAsync({
          id: transaction.id,
          is_partial: false,
          paid_amount: 0,
        });
        toast.success('Segnato come da pagare');
      } else {
        // Mark as paid
        await updateTransaction.mutateAsync({
          id: transaction.id,
          is_partial: true,
          paid_amount: Number(transaction.amount),
        });
        toast.success('Segnato come saldato');
      }
    } catch (error) {
      toast.error('Errore durante l\'aggiornamento');
    }
  };

  return (
    <>
      <div className="flex items-center gap-1">
        {/* Edit */}
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-8 w-8 text-primary hover:text-primary/80"
          onClick={() => setEditOpen(true)}
        >
          <Pencil className="w-4 h-4" />
        </Button>

        {/* Mark as Paid */}
        <Button 
          variant="ghost" 
          size="icon" 
          className={`h-8 w-8 ${isPaid ? 'text-income' : 'text-muted-foreground hover:text-income'}`}
          onClick={handleTogglePaid}
        >
          <Check className="w-4 h-4" />
        </Button>

        {/* Delete */}
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-8 w-8 text-destructive hover:text-destructive/80"
          onClick={() => setDeleteOpen(true)}
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>

      {/* Edit Dialog */}
      <EditTransactionDialog 
        transaction={transaction}
        open={editOpen} 
        onOpenChange={setEditOpen} 
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminare questa transazione?</AlertDialogTitle>
            <AlertDialogDescription>
              Stai per eliminare "{transaction.description || transaction.categories?.name}". Questa azione non può essere annullata.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annulla</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Elimina
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
