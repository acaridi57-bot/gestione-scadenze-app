// Electron entrypoint for packaged builds.
// Using CommonJS require for compatibility with Electron packaging.
require("./electron/main.cjs");
