from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional
import uuid
from datetime import datetime, timezone, date
from enum import Enum


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# Enums
class ScadenzaCategoria(str, Enum):
    FATTURA = "fattura"
    CONTRATTO = "contratto"
    ABBONAMENTO = "abbonamento"
    DOCUMENTO = "documento"
    APPUNTAMENTO = "appuntamento"
    ALTRO = "altro"

class ScadenzaStato(str, Enum):
    ATTIVA = "attiva"
    COMPLETATA = "completata"
    SCADUTA = "scaduta"

class ScadenzaPriorita(str, Enum):
    BASSA = "bassa"
    MEDIA = "media"
    ALTA = "alta"
    URGENTE = "urgente"


# Define Models
class Scadenza(BaseModel):
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    titolo: str
    descrizione: Optional[str] = None
    data_scadenza: str  # ISO format date string
    categoria: ScadenzaCategoria = ScadenzaCategoria.ALTRO
    stato: ScadenzaStato = ScadenzaStato.ATTIVA
    priorita: ScadenzaPriorita = ScadenzaPriorita.MEDIA
    importo: Optional[float] = None
    note: Optional[str] = None
    promemoria_giorni: int = 7  # Days before to remind
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ScadenzaCreate(BaseModel):
    titolo: str
    descrizione: Optional[str] = None
    data_scadenza: str
    categoria: ScadenzaCategoria = ScadenzaCategoria.ALTRO
    priorita: ScadenzaPriorita = ScadenzaPriorita.MEDIA
    importo: Optional[float] = None
    note: Optional[str] = None
    promemoria_giorni: int = 7

class ScadenzaUpdate(BaseModel):
    titolo: Optional[str] = None
    descrizione: Optional[str] = None
    data_scadenza: Optional[str] = None
    categoria: Optional[ScadenzaCategoria] = None
    stato: Optional[ScadenzaStato] = None
    priorita: Optional[ScadenzaPriorita] = None
    importo: Optional[float] = None
    note: Optional[str] = None
    promemoria_giorni: Optional[int] = None


# Helper function to serialize datetime
def serialize_scadenza(scadenza_dict):
    if 'created_at' in scadenza_dict and isinstance(scadenza_dict['created_at'], datetime):
        scadenza_dict['created_at'] = scadenza_dict['created_at'].isoformat()
    if 'updated_at' in scadenza_dict and isinstance(scadenza_dict['updated_at'], datetime):
        scadenza_dict['updated_at'] = scadenza_dict['updated_at'].isoformat()
    return scadenza_dict

def deserialize_scadenza(scadenza_dict):
    if 'created_at' in scadenza_dict and isinstance(scadenza_dict['created_at'], str):
        scadenza_dict['created_at'] = datetime.fromisoformat(scadenza_dict['created_at'])
    if 'updated_at' in scadenza_dict and isinstance(scadenza_dict['updated_at'], str):
        scadenza_dict['updated_at'] = datetime.fromisoformat(scadenza_dict['updated_at'])
    return scadenza_dict


# Routes
@api_router.get("/")
async def root():
    return {"message": "Gestione Scadenze API"}


# CRUD Scadenze
@api_router.post("/scadenze", response_model=Scadenza)
async def create_scadenza(input: ScadenzaCreate):
    scadenza_dict = input.model_dump()
    scadenza_obj = Scadenza(**scadenza_dict)
    
    doc = scadenza_obj.model_dump()
    doc = serialize_scadenza(doc)
    
    await db.scadenze.insert_one(doc)
    return scadenza_obj


@api_router.get("/scadenze", response_model=List[Scadenza])
async def get_scadenze(
    stato: Optional[ScadenzaStato] = None,
    categoria: Optional[ScadenzaCategoria] = None,
    priorita: Optional[ScadenzaPriorita] = None
):
    query = {}
    if stato:
        query["stato"] = stato.value
    if categoria:
        query["categoria"] = categoria.value
    if priorita:
        query["priorita"] = priorita.value
    
    scadenze = await db.scadenze.find(query, {"_id": 0}).to_list(1000)
    
    # Deserialize and update expired status
    today = datetime.now(timezone.utc).date()
    result = []
    for s in scadenze:
        s = deserialize_scadenza(s)
        # Check if scadenza is expired
        try:
            data_scad = datetime.fromisoformat(s['data_scadenza']).date() if isinstance(s['data_scadenza'], str) else s['data_scadenza']
            if data_scad < today and s['stato'] == 'attiva':
                s['stato'] = 'scaduta'
                # Update in database
                await db.scadenze.update_one(
                    {"id": s['id']},
                    {"$set": {"stato": "scaduta", "updated_at": datetime.now(timezone.utc).isoformat()}}
                )
        except:
            pass
        result.append(s)
    
    # Sort by data_scadenza
    result.sort(key=lambda x: x.get('data_scadenza', ''))
    return result


@api_router.get("/scadenze/{scadenza_id}", response_model=Scadenza)
async def get_scadenza(scadenza_id: str):
    scadenza = await db.scadenze.find_one({"id": scadenza_id}, {"_id": 0})
    if not scadenza:
        raise HTTPException(status_code=404, detail="Scadenza non trovata")
    return deserialize_scadenza(scadenza)


@api_router.put("/scadenze/{scadenza_id}", response_model=Scadenza)
async def update_scadenza(scadenza_id: str, input: ScadenzaUpdate):
    scadenza = await db.scadenze.find_one({"id": scadenza_id}, {"_id": 0})
    if not scadenza:
        raise HTTPException(status_code=404, detail="Scadenza non trovata")
    
    update_data = input.model_dump(exclude_unset=True)
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    await db.scadenze.update_one(
        {"id": scadenza_id},
        {"$set": update_data}
    )
    
    updated_scadenza = await db.scadenze.find_one({"id": scadenza_id}, {"_id": 0})
    return deserialize_scadenza(updated_scadenza)


@api_router.delete("/scadenze/{scadenza_id}")
async def delete_scadenza(scadenza_id: str):
    result = await db.scadenze.delete_one({"id": scadenza_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Scadenza non trovata")
    return {"message": "Scadenza eliminata con successo"}


# Dashboard stats
@api_router.get("/dashboard/stats")
async def get_dashboard_stats():
    today = datetime.now(timezone.utc).date()
    today_str = today.isoformat()
    
    # Get all scadenze
    all_scadenze = await db.scadenze.find({}, {"_id": 0}).to_list(1000)
    
    totale = len(all_scadenze)
    attive = 0
    completate = 0
    scadute = 0
    in_scadenza_7_giorni = 0
    importo_totale = 0
    
    for s in all_scadenze:
        stato = s.get('stato', 'attiva')
        if stato == 'completata':
            completate += 1
        elif stato == 'scaduta':
            scadute += 1
        else:
            try:
                data_scad = datetime.fromisoformat(s['data_scadenza']).date()
                if data_scad < today:
                    scadute += 1
                else:
                    attive += 1
                    days_until = (data_scad - today).days
                    if days_until <= 7:
                        in_scadenza_7_giorni += 1
            except:
                attive += 1
        
        if s.get('importo'):
            importo_totale += s['importo']
    
    return {
        "totale": totale,
        "attive": attive,
        "completate": completate,
        "scadute": scadute,
        "in_scadenza_7_giorni": in_scadenza_7_giorni,
        "importo_totale": round(importo_totale, 2)
    }


# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
